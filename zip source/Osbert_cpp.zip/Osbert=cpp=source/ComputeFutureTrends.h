#ifndef _COMPUTEFUTURETRENDS
#define _COMPUTEFUTURETRENDS


class ComputeFutureTrends
{

public:

	void static compute (void);		// determines the trendy artists

private:

    bool static overTarget (string fn, string ln);		// determine if a painter has been sold over target

}; // class ComputeFutureTrends

#endif
