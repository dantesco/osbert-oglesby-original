#ifndef _TRENDSREPORT
#define _TRENDSREPORT

class FutureTrendsReport
{

public:

	void static printReport (string tempFn, string tempLn);		// displays a trend report for a specific painter

}; // class FutureTrendsReport

#endif
