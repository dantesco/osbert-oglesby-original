#ifndef _MASTERPIECE
#define _MASTERPIECE


#include "GalleryPainting.h"

class Masterpiece : public GalleryPainting
{

public:

	Masterpiece ()	{ classification = "Masterpiece"; }

}; // class Masterpiece

#endif
