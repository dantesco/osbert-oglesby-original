#ifndef _MASTERWORK
#define _MASTERWORK


#include "Masterpiece.h"

class Masterwork : public Masterpiece
{

public:

	Masterwork () { classification = "Masterwork"; }

}; // class Masterwork

#endif
