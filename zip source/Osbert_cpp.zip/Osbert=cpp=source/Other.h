#ifndef _OTHER
#define _OTHER


#include "GalleryPainting.h"

class Other : public GalleryPainting
{

public:

	Other () { classification = "Other"; }

}; // class Other

#endif
