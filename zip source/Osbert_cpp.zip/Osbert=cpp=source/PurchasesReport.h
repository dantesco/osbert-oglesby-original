#ifndef _PURCHASESREPORT
#define _PURCHASESREPORT

class PurchasesReport
{

public:


	void static printReport (void);	// displays a report of bought paintings

}; // class PurchasesReport

#endif
