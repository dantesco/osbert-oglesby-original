#ifndef _SALESREPORT
#define _SALESREPORT

class SalesReport
{

public:

	void static printReport (void);	// displays a report of sold paintings

}; // class SalesReport

#endif
