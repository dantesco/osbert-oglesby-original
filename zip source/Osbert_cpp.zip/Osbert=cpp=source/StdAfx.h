// stdafx.h : include file for standard system include files,

#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <ctype.h>
#include <string>
#include <ostream>
#include <iostream>
#include <ctime>

using namespace std;

